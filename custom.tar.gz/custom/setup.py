import setuptools

setuptools.setup(

    install_requires=[

        'cloudml-hypertune', 'gcsfs' 

    ],

    packages=setuptools.find_packages())
